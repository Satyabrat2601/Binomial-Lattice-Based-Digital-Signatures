#include "cpucycles.h"
#include <stdint.h>

uint64_t cpucycles_overhead(void) {
    uint64_t t0, t1, overhead = UINT64_MAX;
    for (unsigned i = 0; i < 100000; i++) {
        t0 = cpucycles();
        __asm__ volatile("");
        t1 = cpucycles();
        if (t1 - t0 < overhead) overhead = t1 - t0;
    }
    return overhead;
}
